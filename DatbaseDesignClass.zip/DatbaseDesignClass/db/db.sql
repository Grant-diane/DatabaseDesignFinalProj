CREATE DATABASE spotipy;

CREATE
USER 'webapp'@'%' IDENTIFIED BY 'abc123';
GRANT ALL PRIVILEGES ON spotipy.* TO 'webapp'@'%';
FLUSH PRIVILEGES;

USE spotipy;

CREATE TABLE Album (
    albumID     varchar(255) PRIMARY KEY,
    releaseDate DATE,
    numOfTracks int,
    name        varchar(255),
    artistID    varchar(255),
    producerID  varchar(255),
    FOREIGN KEY (artistID) REFERENCES Artist (artistID),
    FOREIGN KEY (producerID) REFERENCES Producer (producerID)
);

CREATE TABLE Artist(
    artistID   varchar(255) PRIMARY KEY,
    name       varchar(225),
    numOfSongs int,
    listeners  varchar(255),
    worksWith  varchar(255),
    FOREIGN KEY (listeners) REFERENCES Listens_to (listensToID),
    FOREIGN KEY (worksWith) REFERENCES Works_with (worksWithID)
);

CREATE TABLE Listens_to(
    listensToID      varchar(255) PRIMARY KEY,
    monthlyListeners int,
    artistID         varchar(255),
    listenerID       varchar(255),
    FOREIGN KEY (artistID) REFERENCES Artist (artistID),
    FOREIGN KEY (listenerID) REFERENCES Listener (username)
);

CREATE TABLE Works_with(
    worksWithID varchar(255) PRIMARY KEY,
    artistID    varchar(255),
    producerID  varchar(255),
    label       varchar(255),
    FOREIGN KEY (artistID) REFERENCES Artist (artistID),
    FOREIGN KEY (producerID) REFERENCES Producer (producerID)
);

CREATE TABLE Genre(
    genreID varchar(255) PRIMARY KEY,
    name    varchar(255)
);

CREATE TABLE Listener(
    username         varchar(255) PRIMARY KEY,
    creationTime     time,
    postalCode       varchar(255),
    birthdate        date,
    country          varchar(255),
    gender           varchar(255),
    mobileNumber     varchar(10),
    email            varchar(255),
    friends          varchar(255),
    podcastListeners varchar(255),
    listeners        varchar(255),
    listenedSongs    varchar(255),
    playlists        varchar(255),
    FOREIGN KEY (friends) REFERENCES Friends (friendRelID),
    FOREIGN KEY (podcastListeners) REFERENCES Podcast_Listener (podListenerID),
    FOREIGN KEY (listeners) REFERENCES Listens_to (listensToID),
    FOREIGN KEY (listenedSongs) REFERENCES Listened_songs (listenedSongsID),
    FOREIGN KEY (playlists) REFERENCES Playlist_Maker (playlistMakerID)
);

CREATE TABLE Listened_songs(
    listenedSongsID varchar(255),
    listenerID      varchar(255),
    songID          varchar(255),
    FOREIGN KEY (listenerID) REFERENCES Listener (username),
    FOREIGN KEY (songID) REFERENCES Songs (songID)
);

CREATE TABLE Friends(
    friendRelID varchar(255) PRIMARY KEY,
    friend1ID   varchar(255),
    friend2ID   varchar(255),
    FOREIGN KEY (friend1ID) REFERENCES Listener (username),
    FOREIGN KEY (friend2ID) REFERENCES Listener (username)
);

CREATE TABLE Podcast_Listener(
    podListenerID varchar(255) PRIMARY KEY,
    timePlayed    int,
    podcastID     varchar(255),
    listenerID    varchar(255),
    FOREIGN KEY (podcastID) REFERENCES Podcast (podcastId),
    FOREIGN KEY (listenerID) REFERENCES Listener (username)
);

CREATE TABLE Playlist(
    playlistID  varchar(255) PRIMARY KEY,
    dateCreated date,
    name        varchar(255),
    length      int,
    numOfSongs  int,
    makers      varchar(255),
    songs       varchar(255),
    FOREIGN KEY (makers) REFERENCES Playlist_Maker (playlistMakerID),
    FOREIGN KEY (songs) REFERENCES SongsInPlaylist (songPlaylistID)
);

CREATE TABLE Playlist_Maker(
    playlistMakerID varchar(255),
    playlistID      varchar(255),
    listenerID      varchar(255),
    minutesPlayed   int,
    FOREIGN KEY (playlistID) REFERENCES Playlist (playlistID),
    FOREIGN KEY (listenerID) REFERENCES Listener (username)
);

CREATE TABLE SongsInPlaylist(
    songPlaylistID varchar(255),
    songID         varchar(255),
    playlistID     varchar(255),
    FOREIGN KEY (songID) REFERENCES Songs (songID),
    FOREIGN KEY (playlistID) REFERENCES Playlist (playlistID)
);

CREATE TABLE Podcast(
    podcastId     varchar(255) PRIMARY KEY,
    title         varchar(255),
    releaseDate   date,
    sponsor       varchar(255),
    numOfEpisodes int,
    artistID      varchar(255),
    listeners     varchar(255),
    FOREIGN KEY (artistID) REFERENCES Artist (artistID),
    FOREIGN KEY (listeners) REFERENCES Podcast_Listener (podListenerID)
);

CREATE TABLE Producer(
    producerID    varchar(255) PRIMARY KEY,
    numOfSongs    int,
    name          varchar(255),
    worksWith     varchar(255),
    songsProduced varchar(255),
    FOREIGN KEY (worksWith) REFERENCES Works_with (worksWithID),
    FOREIGN KEY (songsProduced) REFERENCES Song_Prod (songProdID)
);

CREATE TABLE Song_Prod(
    songProdID varchar(255),
    producerID varchar(255),
    songID     varchar(255),
    FOREIGN KEY (songID) REFERENCES Songs (songID),
    FOREIGN KEY (producerID) REFERENCES Producer (producerID)
);

CREATE TABLE Songs(
    songID       varchar(255) PRIMARY KEY,
    trackURL     varchar(255),
    msPlayed     int,
    tackName     varChar(255),
    length       int,
    genreID      varchar(255),
    performerID  varchar(255),
    albumOnID    varchar(255),
    producedByID varchar(255),
    playlists    varchar(255),
    listeners    varchar(255),
    FOREIGN KEY (genreID) REFERENCES Genre (genreID),
    FOREIGN KEY (performerID) REFERENCES Artist (artistID),
    FOREIGN KEY (albumOnID) REFERENCES Album (albumID),
    FOREIGN KEY (producedByID) REFERENCES Producer (producerID),
    FOREIGN KEY (playlists) REFERENCES SongsInPlaylist (songPlaylistID),
    FOREIGN KEY (listeners) REFERENCES Listened_songs (listenedSongsID)
);

INSERT INTO Album VALUES (001, 11/23/2002, 15, 'Sounds', 005, 004);
INSERT INTO Album VALUES (002, 03/04/1986, 20, 'Ghost', 003, 001);
INSERT INTO Album VALUES (003, 08/08/1999, 19, 'Flying', 001, 002);
INSERT INTO Album VALUES (004, 09/24/2020, 17, 'Radio', 002, 003);
INSERT INTO Album VALUES (005, 02/09/2017, 29, 'Carseat', 002, 005);

INSERT INTO Artist VALUES (001, 'Maxx', 80, 001, 001);
INSERT INTO Artist VALUES (002, 'Joani', 72, 002, 002);
INSERT INTO Artist VALUES (003, 'Daisy', 32,  003, 003);
INSERT INTO Artist VALUES (004, 'Betty', 1, 004, 004);
INSERT INTO Artist VALUES (005, 'ALEXGREAT', 18, 005, 005);

INSERT INTO Listens_to VALUES (001, 4000, 001, 002);
INSERT INTO Listens_to VALUES (002, 500, 002, 001);
INSERT INTO Listens_to VALUES (003, 345000, 002, 004);
INSERT INTO Listens_to VALUES (004, 899900, 003, 005);
INSERT INTO Listens_to VALUES (005, 2000000, 005, 003);

INSERT INTO Works_with VALUES (001, 001, 002, 'BigName');
INSERT INTO Works_with VALUES (002, 002, 003, 'SmallName');
INSERT INTO Works_with VALUES (003, 003, 001, 'BigName');
INSERT INTO Works_with VALUES (004, 004, 005, 'DoorPost');
INSERT INTO Works_with VALUES (005, 005, 004, 'WindowFrame');

INSERT INTO Genre VALUES (001, 'Rock');
INSERT INTO Genre VALUES (002, 'Pop');
INSERT INTO Genre VALUES (003, 'Jazz');
INSERT INTO Genre VALUES (004, 'R_and_B');
INSERT INTO Genre VALUES (005, 'Folk');

insert into Listener values (1, '10:16 AM', '02115', '7/3/2022', 'Canada', 'Female', '891-381-3755', 'shills0@sbwire.com', 1, 1, 1, 1, 1);
insert into Listener values (2, '11:18 AM', '02116', '10/15/2022', 'Indonesia', 'Male', '580-747-6821', 'bstlouis1@phoca.cz', 2, 2, 2, 2, 2);
insert into Listener values (3, '3:34 PM', '28950', '6/15/2022', 'Turkmenistan', 'Female', '660-528-3630', 'lvoysey2@w3.org', 3, 3, 3, 3, 3);
insert into Listener values (4, '11:04 PM', '76201', '11/10/2022', 'Canada', 'Female', '622-622-3980', 'swinridge3@hhs.gov', 4, 4, 4, 4, 4);
insert into Listener values (5, '9:40 AM', '04536', '5/24/2022', 'Philippines', 'Male', '974-276-9527', 'tleddie4@google.pl', 5, 5, 5, 5, 5);

insert into Listened_songs values (1, 1, 1);
insert into Listened_songs values (2, 2, 2);
insert into Listened_songs values (3, 3, 3);
insert into Listened_songs values (4, 4, 4);
insert into Listened_songs values (5, 5, 5);

insert into Friends values (1, 1, 1);
insert into Friends values (2, 2, 2);
insert into Friends values (3, 3, 3);
insert into Friends values (4, 4, 4);
insert into Friends values (5, 5, 5);

insert into Podcast_Listener values (1, 3456, 1, 1);
insert into Podcast_Listener values (2, 89000, 2, 2);
insert into Podcast_Listener values (3, 23022, 3, 3);
insert into Podcast_Listener values (4, 20000, 4, 4);
insert into Podcast_Listener values (5, 876, 5, 5);

insert into Playlist values (1, 02/27/2021, 'nap time', 278, 20, 1, 1);
insert into Playlist values (2, 02/27/2021, 'party time', 278, 20, 2, 2);
insert into Playlist values (3, 02/27/2021, 'study time', 278, 20, 3, 3);
insert into Playlist values (4, 02/27/2021, 'dinner time', 278, 20, 4, 4);
insert into Playlist values (5, 02/27/2021, 'travel time', 278, 20, 5, 5);

insert into Playlist_Maker values (1, 1, 1, 46748596);
insert into Playlist_Maker values (2, 2, 2, 364);
insert into Playlist_Maker values (3, 3, 3, 3456);
insert into Playlist_Maker values (4, 4, 4, 8653);
insert into Playlist_Maker values (5, 5, 5, 84);

insert into SongsInPlaylist values (1, 1, 1);
insert into SongsInPlaylist values (2, 2, 2);
insert into SongsInPlaylist values (3, 3, 3);
insert into SongsInPlaylist values (4, 4, 4);
insert into SongsInPlaylist values (5, 5, 5);

insert into Podcast values (1, 'Planet Money', 09/02/2021, 'Clorox', 12, 1, 1);
insert into Podcast values (2, 'NPR News', 09/02/2021, 'Red Sox', 90, 2, 2);
insert into Podcast values (3, 'Lore', 09/02/2021, 'Old Spice', 899, 3, 3);
insert into Podcast values (4, 'National Parks After Dark', 09/02/2021, 'Beats', 03, 4, 4);
insert into Podcast values (5, 'Ologies with Alie Ward', 09/02/2021, 'Otterbox', 100, 5, 5);

insert into Producer values (1, 12, 'Millie', 1, 1);
insert into Producer values (2, 122, 'Bobbie', 2, 2);
insert into Producer values (3, 45, 'Brown', 3, 3);
insert into Producer values (4, 90, 'JacksonJ', 4, 4);
insert into Producer values (5, 200, 'Samuel Sam', 5, 5);

insert into Song_Prod values (1, 1, 1);
insert into Song_Prod values (2, 2, 2);
insert into Song_Prod values (3, 3, 3);
insert into Song_Prod values (4, 4, 4);
insert into Song_Prod values (5, 5, 5);

insert into Songs values (1, 'https://open.spotify.com/track/3AgqQbQWYLGsemeBHk1U1d?si=6bd8b561b5a646de', 5000, 'Autumn Leaves', 5500, 3, 1, 1, 1, 1, 1);
insert into Songs values (2, 'https://open.spotify.com/track/6qMMQzYTKabamnMPlCmfxb?si=85414c2662ed4b99', 4000, 'On the Street Where You Live', 4510, 1, 2, 2, 2, 2, 2);
insert into Songs values (3, 'https://open.spotify.com/track/0UqcNRmbuZuxUihXzdQ2br?si=c101b54e28874aa3', 9820, 'Back Bay Shuffle', 8736, 2, 3, 3, 3, 3, 3);
insert into Songs values (4, 'https://open.spotify.com/track/3KzgdYUlqV6TOG7JCmx2Wg?si=1de371c17b1e42a4', 1000, 'Beyond the Sea', 1100, 5, 4, 4, 4, 4, 4);
insert into Songs values (5, 'https://open.spotify.com/track/1cpANF6zMBoFoxkoIjZHjv?si=8d72be3a0338487c', 16000, 'Skating in Central Park', 16400, 4, 5, 5, 5, 5, 5);

SHOW DATABASES;